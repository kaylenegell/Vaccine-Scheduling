class Patient:
    pass
